# Extension Debugging Guide

This guide explains how to debug the extension and view logs to troubleshoot recording issues.

## Logging Overview

The extension now includes comprehensive logging with prefixes to help identify where logs come from:

- `[Popup]` - Logs from the popup UI
- `[Background]` - Logs from the background service worker
- `[Record]` - Logs from the recording module
- `[Content]` - Logs from the content script (injected into web pages)
- `[Injected Script]` - Logs from dynamically injected scripts

## How to View Logs

### 1. Popup Logs

1. Open the extension popup (click the extension icon)
2. Right-click inside the popup and select **"Inspect"** or **"Inspect Popup"**
3. Go to the **Console** tab
4. Click the "Start Recording" button
5. You should see logs prefixed with `[Popup]`

### 2. Background Service Worker Logs

1. Go to `chrome://extensions/` (or `edge://extensions/` for Edge)
2. Find your extension "AutoDoc"
3. Click **"service worker"** link (or "Inspect views: service worker")
4. This opens DevTools for the background script
5. Go to the **Console** tab
6. You should see logs prefixed with `[Background]` and `[Record]`

### 3. Content Script Logs

1. Open the web page where you're trying to record
2. Press `F12` or right-click and select **"Inspect"**
3. Go to the **Console** tab
4. You should see logs prefixed with `[Content]`

**Note:** Content script logs appear in the **web page's console**, not the extension console.

## Recording Flow

When you click "Start Recording", the following sequence should occur:

1. **Popup** → Sends `START_RECORDING` message
   - Look for: `[Popup] Start button clicked`
   - Look for: `[Popup] Sending START_RECORDING message to background...`

2. **Background** → Receives message and calls `startRecording()`
   - Look for: `[Background] START_RECORDING message received`
   - Look for: `[Record] startRecording() called`

3. **Record Module** → Initializes recording
   - Look for: `[Record] Active tab found`
   - Look for: `[Record] Workflow created`
   - Look for: `[Record] Injecting script to dispatch scribe-start-recording event...`

4. **Injected Script** → Dispatches event to content script
   - Look for: `[Injected Script] Dispatching scribe-start-recording event`
   - Look for: `[Injected Script] Event dispatched`

5. **Content Script** → Receives event and starts capturing
   - Look for: `[Content] scribe-start-recording event received!`
   - Look for: `[Content] Starting event capture...`
   - Look for: `[Content] Event capture fully initialized`

## Common Issues and What to Check

### Issue: "Failed to start recording" alert

**Check:**
1. Background service worker console - look for errors
2. Check if `[Record] startRecording() called` appears
3. Check for permission errors or tab access issues

### Issue: Recording starts but no events captured

**Check:**
1. Content script console (web page console) - verify `[Content] scribe-start-recording event received!`
2. Check if `[Content] Event capture fully initialized` appears
3. Try clicking/interacting with the page and check for `[Content] Click event captured`

### Issue: Content script not receiving event

**Check:**
1. Background console - verify `[Record] Script injected successfully`
2. Check for injection errors in background console
3. Content script console - verify the script is loaded (should see `[Content] Content script loaded`)
4. Check if the page URL matches content script permissions in manifest.json

### Issue: Extension not responding

**Check:**
1. Background service worker - verify it's running (should see `[Background] Service worker initialized`)
2. Check if service worker was terminated (Chrome may terminate inactive service workers)
3. Reload the extension from `chrome://extensions/`

## Filtering Logs

In Chrome DevTools Console, you can filter logs by prefix:

- Type `[Popup]` to see only popup logs
- Type `[Background]` to see only background logs
- Type `[Content]` to see only content script logs
- Type `[Record]` to see only recording module logs

## Tips

1. **Keep all three consoles open** (popup, background, content) to see the full flow
2. **Clear console before testing** to see only new logs
3. **Check for red errors** - they indicate where the flow breaks
4. **Verify permissions** - some issues are caused by missing permissions in manifest.json

## Rebuilding the Extension

After making changes, rebuild the extension:

```bash
cd extension
npm run build
```

Then reload the extension in Chrome:
1. Go to `chrome://extensions/`
2. Click the reload icon on your extension
3. Close and reopen the popup to test

## Additional Debugging

### Check Extension Storage

1. Open background service worker console
2. Run: `chrome.storage.local.get(null, console.log)`
3. This shows all stored data including `currentWorkflow` and `isRecording`

### Check Active Tab

1. Open background service worker console
2. Run: `chrome.tabs.query({active: true, currentWindow: true}, console.log)`
3. This shows the currently active tab information

### Manual Event Dispatch (for testing)

If the injected script isn't working, you can manually trigger the event:

1. Open the web page console (content script console)
2. Run: `window.dispatchEvent(new CustomEvent('scribe-start-recording'))`
3. Check if `[Content] scribe-start-recording event received!` appears

