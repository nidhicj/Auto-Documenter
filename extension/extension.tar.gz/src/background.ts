import { recordEvent, startRecording, stopRecording, getRecordingStatus } from './record';
import { processOfflineQueue, checkConnectionAndProcessQueue } from './offlineQueue';
import { DOMEvent } from './types';

// Listen for messages from content script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Background] Message received:', {
    type: message.type,
    sender: sender.tab?.id ? `tab-${sender.tab.id}` : 'popup',
    url: sender.tab?.url,
  });

  if (message.type === 'DOM_EVENT') {
    const event = message.event as DOMEvent;
    console.log('[Background] DOM_EVENT received:', event.type, event.target?.selector);
    recordEvent(event).catch((error) => {
      console.error('[Background] Error recording DOM event:', error);
    });
    sendResponse({ success: true });
  } else if (message.type === 'START_RECORDING') {
    console.log('[Background] START_RECORDING message received, calling startRecording()...');
    startRecording()
      .then(() => {
        console.log('[Background] startRecording() completed successfully');
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error('[Background] startRecording() failed:', error);
        console.error('[Background] Error details:', {
          message: error.message,
          stack: error.stack,
          name: error.name,
        });
        sendResponse({ success: false, error: error.message });
      });
    return true; // Async response
  } else if (message.type === 'STOP_RECORDING') {
    console.log('[Background] STOP_RECORDING message received');
    stopRecording()
      .then(() => {
        console.log('[Background] stopRecording() completed successfully');
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error('[Background] stopRecording() failed:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Async response
  } else if (message.type === 'GET_RECORDING_STATUS') {
    const status = getRecordingStatus();
    console.log('[Background] GET_RECORDING_STATUS requested, returning:', status);
    sendResponse({ isRecording: status });
  } else {
    console.warn('[Background] Unknown message type:', message.type);
  }
});

// Process offline queue on startup
chrome.runtime.onStartup.addListener(() => {
  checkConnectionAndProcessQueue();
});

// Process offline queue when extension is installed/updated
chrome.runtime.onInstalled.addListener(() => {
  checkConnectionAndProcessQueue();
});

// Listen for tab navigation to capture navigation events
chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0 && getRecordingStatus()) {
    // Main frame navigation
    const event: DOMEvent = {
      type: 'navigation',
      target: {
        tagName: 'BODY',
        selector: 'body',
      },
      url: details.url,
      timestamp: Date.now(),
    };
    recordEvent(event).catch(console.error);
  }
});

// Periodic check for offline queue (every 30 seconds)
setInterval(() => {
  checkConnectionAndProcessQueue();
}, 30000);

console.log('[Background] Service worker initialized');



