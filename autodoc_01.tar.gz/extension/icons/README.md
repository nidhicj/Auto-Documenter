# Extension Icons

Place icon files here:
- icon16.png (16x16)
- icon48.png (48x48)
- icon128.png (128x128)

You can generate these from a single high-resolution icon using an image editor or online tool.




