"use strict";
console.log('[Popup] Popup script loaded');
const btnStart = document.getElementById('btnStart');
const btnStop = document.getElementById('btnStop');
const statusElement = document.getElementById('status');
if (!btnStart || !btnStop || !statusElement) {
    console.error('[Popup] Failed to find required DOM elements:', {
        btnStart: !!btnStart,
        btnStop: !!btnStop,
        statusElement: !!statusElement,
    });
}
else {
    console.log('[Popup] DOM elements found successfully');
}
// Check recording status on load
console.log('[Popup] Initial status check...');
updateStatus();
// Start recording
btnStart.addEventListener('click', async () => {
    console.log('[Popup] Start button clicked');
    try {
        console.log('[Popup] Sending START_RECORDING message to background...');
        const response = await chrome.runtime.sendMessage({ type: 'START_RECORDING' });
        console.log('[Popup] Received response from background:', response);
        if (response && response.success) {
            console.log('[Popup] Recording started successfully');
            updateStatus();
        }
        else {
            const errorMsg = response?.error || 'Unknown error';
            console.error('[Popup] Failed to start recording:', errorMsg);
            alert(`Failed to start recording: ${errorMsg}`);
        }
    }
    catch (error) {
        console.error('[Popup] Exception while starting recording:', error);
        console.error('[Popup] Error details:', {
            message: error instanceof Error ? error.message : String(error),
            stack: error instanceof Error ? error.stack : undefined,
        });
        alert(`Failed to start recording: ${error instanceof Error ? error.message : String(error)}`);
    }
});
// Stop recording
btnStop.addEventListener('click', async () => {
    try {
        const response = await chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
        if (response.success) {
            updateStatus();
        }
        else {
            alert(`Failed to stop recording: ${response.error}`);
        }
    }
    catch (error) {
        console.error('Failed to stop recording:', error);
        alert('Failed to stop recording');
    }
});
// Update UI status
async function updateStatus() {
    try {
        console.log('[Popup] Checking recording status...');
        const response = await chrome.runtime.sendMessage({ type: 'GET_RECORDING_STATUS' });
        console.log('[Popup] Status response:', response);
        const isRecording = response?.isRecording ?? false;
        if (isRecording) {
            statusElement.textContent = '🔴 Recording...';
            statusElement.className = 'status recording';
            btnStart.disabled = true;
            btnStop.disabled = false;
            console.log('[Popup] Status updated: Recording');
        }
        else {
            statusElement.textContent = 'Ready to record';
            statusElement.className = 'status idle';
            btnStart.disabled = false;
            btnStop.disabled = true;
            console.log('[Popup] Status updated: Idle');
        }
    }
    catch (error) {
        console.error('[Popup] Failed to get status:', error);
    }
}
// Poll status every second when recording
setInterval(() => {
    updateStatus();
}, 1000);
