let isRecording = false;
console.log('[Content] Content script loaded at:', window.location.href);
console.log('[Content] Setting up event listeners...');
// Listen for recording start/stop
window.addEventListener('scribe-start-recording', () => {
    console.log('[Content] scribe-start-recording event received!');
    console.log('[Content] Current URL:', window.location.href);
    console.log('[Content] Document ready state:', document.readyState);
    if (isRecording) {
        console.warn('[Content] Already recording, ignoring duplicate start event');
        return;
    }
    isRecording = true;
    console.log('[Content] Starting event capture...');
    startEventCapture();
    console.log('[Content] Event capture started');
});
window.addEventListener('scribe-stop-recording', () => {
    console.log('[Content] scribe-stop-recording event received');
    if (!isRecording) {
        console.warn('[Content] Not recording, ignoring stop event');
        return;
    }
    isRecording = false;
    console.log('[Content] Stopping event capture...');
    stopEventCapture();
    console.log('[Content] Event capture stopped');
});
/**
 * Start capturing DOM events
 */
function startEventCapture() {
    console.log('[Content] startEventCapture() called');
    if (!document.body) {
        console.error('[Content] document.body is null, cannot start event capture');
        return;
    }
    console.log('[Content] Adding click event listener...');
    // Click events
    document.addEventListener('click', handleClick, true);
    console.log('[Content] Adding input event listener...');
    // Input events
    document.addEventListener('input', handleInput, true);
    console.log('[Content] Setting up MutationObserver...');
    // DOM mutations
    const observer = new MutationObserver(handleDOMChange);
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeOldValue: true,
    });
    console.log('[Content] MutationObserver started');
    // Navigation (SPA)
    console.log('[Content] Setting up navigation monitoring...');
    let lastUrl = location.href;
    const navInterval = setInterval(() => {
        if (location.href !== lastUrl) {
            handleNavigation(lastUrl, location.href);
            lastUrl = location.href;
        }
    }, 1000);
    console.log('[Content] Navigation monitoring started');
    // Store observer and interval for cleanup
    window.__scribeObserver = observer;
    window.__scribeNavInterval = navInterval;
    console.log('[Content] Event capture fully initialized');
}
/**
 * Stop capturing DOM events
 */
function stopEventCapture() {
    console.log('[Content] stopEventCapture() called');
    document.removeEventListener('click', handleClick, true);
    document.removeEventListener('input', handleInput, true);
    const observer = window.__scribeObserver;
    if (observer) {
        observer.disconnect();
        delete window.__scribeObserver;
        console.log('[Content] MutationObserver disconnected');
    }
    const navInterval = window.__scribeNavInterval;
    if (navInterval) {
        clearInterval(navInterval);
        delete window.__scribeNavInterval;
        console.log('[Content] Navigation monitoring stopped');
    }
    console.log('[Content] Event capture stopped');
}
/**
 * Handle click events
 */
function handleClick(event) {
    if (!isRecording) {
        console.log('[Content] Click event ignored (not recording)');
        return;
    }
    const target = event.target;
    const domEvent = {
        type: 'click',
        target: {
            tagName: target.tagName,
            id: target.id || undefined,
            className: target.className?.toString() || undefined,
            textContent: target.textContent?.slice(0, 100) || undefined,
            selector: getSelector(target),
        },
        url: window.location.href,
        timestamp: Date.now(),
        metadata: {
            x: event.clientX,
            y: event.clientY,
        },
    };
    console.log('[Content] Click event captured:', {
        selector: domEvent.target.selector,
        tagName: domEvent.target.tagName,
    });
    sendEventToBackground(domEvent);
}
/**
 * Handle input events
 */
function handleInput(event) {
    if (!isRecording)
        return;
    const target = event.target;
    const domEvent = {
        type: 'input',
        target: {
            tagName: target.tagName,
            id: target.id || undefined,
            className: target.className?.toString() || undefined,
            selector: getSelector(target),
        },
        url: window.location.href,
        timestamp: Date.now(),
        metadata: {
            valueLength: target.value.length,
            inputType: target.type,
        },
    };
    sendEventToBackground(domEvent);
}
/**
 * Handle DOM changes
 */
function handleDOMChange(mutations) {
    if (!isRecording)
        return;
    // Throttle DOM change events
    const now = Date.now();
    if (window.__lastDOMChangeTime && now - window.__lastDOMChangeTime < 1000) {
        return;
    }
    window.__lastDOMChangeTime = now;
    const domEvent = {
        type: 'dom_change',
        target: {
            tagName: 'BODY',
            selector: 'body',
        },
        url: window.location.href,
        timestamp: Date.now(),
        metadata: {
            mutationCount: mutations.length,
        },
    };
    sendEventToBackground(domEvent);
}
/**
 * Handle navigation (SPA)
 */
function handleNavigation(from, to) {
    if (!isRecording)
        return;
    const domEvent = {
        type: 'navigation',
        target: {
            tagName: 'BODY',
            selector: 'body',
        },
        url: to,
        timestamp: Date.now(),
        metadata: {
            from,
            to,
        },
    };
    sendEventToBackground(domEvent);
}
/**
 * Get CSS selector for element
 */
function getSelector(element) {
    if (element.id) {
        return `#${element.id}`;
    }
    if (element.className) {
        const classes = element.className.toString().split(' ').filter(Boolean);
        if (classes.length > 0) {
            return `${element.tagName.toLowerCase()}.${classes[0]}`;
        }
    }
    return element.tagName.toLowerCase();
}
/**
 * Send event to background script
 */
function sendEventToBackground(event) {
    console.log('[Content] Sending event to background:', event.type);
    chrome.runtime.sendMessage({
        type: 'DOM_EVENT',
        event,
    })
        .then(() => {
        console.log('[Content] Event sent successfully:', event.type);
    })
        .catch((error) => {
        console.error('[Content] Failed to send event:', error);
        console.error('[Content] Error details:', {
            message: error.message,
            eventType: event.type,
        });
    });
}
export {};
